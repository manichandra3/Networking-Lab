
def stringToList(inp):
    return list(inp)


string1 = input()
print(stringToList(string1))
