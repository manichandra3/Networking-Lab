n = int(input('Enter the length of the list:'))
# list comprehension
squares = [i**2 for i in range(n+1)]
print(squares)
