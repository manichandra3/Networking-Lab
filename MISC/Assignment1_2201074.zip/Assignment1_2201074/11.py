n = int(input('Enter a number:'))
# dictionary comprehension
dictionary = {i: i ** 2 for i in range(n + 1)}
print(dictionary)