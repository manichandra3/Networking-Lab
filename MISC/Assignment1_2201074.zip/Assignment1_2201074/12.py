class Foo:
    def __init__(self, *args):
        self.values = list(args)

    def apply(self, func):
        try:
            return [func(value) for value in self.values]
        except Exception as e:
            raise Exception(f"Failed to apply function: {str(e)}")


# n = int(input('Enter the length of the list: '))
# list1 = list(map(int, input('Enter the integer elements of the list: ').strip().split()))[:n]
Bar = Foo(1, 2, 3, 4)
print(Bar.apply(lambda x: x * 2))
