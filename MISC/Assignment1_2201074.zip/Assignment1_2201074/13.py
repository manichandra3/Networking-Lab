n = int(input('Enter the length of the list: '))
words = list(map(str, input('Enter the words: ').split()))[:n]


def uppercase_words(inp):
    # Use 'map' to apply the str.upper function to each word in the list
    return list(map(str.upper, inp))


print(uppercase_words(words))
