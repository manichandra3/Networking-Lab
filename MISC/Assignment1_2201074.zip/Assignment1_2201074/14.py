import functools

n = int(input('Enter the length of the list: '))
list1 = list(map(int, input('Enter the elements of the list: ').split()))[:n]
# pairs are taken to perform lambda, and this process is continued till no elements are left in the list.
res = functools.reduce(lambda x, y: x*y, list1)
print(res)
