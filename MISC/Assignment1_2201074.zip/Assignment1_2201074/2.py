def ListToString(List):
    # join with empty list
    return ''.join(List)


string1 = ['a', 'b', 'c', 'd']
print(ListToString(string1))
