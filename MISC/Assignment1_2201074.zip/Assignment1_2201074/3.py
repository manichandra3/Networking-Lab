import random


def generateNRandom(number):
    randList = []
    for i in range(number):
        randList.append(random.randint(1, 10))
    return randList


num = int(input("Enter a number: "))
randomList = generateNRandom(num)
print(randomList)
