n = int(input('Enter the length of the list: '))

inputList = list(map(int, input("\nEnter the numbers : ").strip().split()))[:n]

print(inputList)
print(sorted(inputList, reverse=True))
