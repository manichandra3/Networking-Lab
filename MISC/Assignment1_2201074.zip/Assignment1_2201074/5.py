n = int(input('Enter the length of the list: '))
inputList = list(map(int, input("Enter the numbers : ").strip().split()))[:n]
print(inputList)

dictionary = {}
# increment items found in list else initialize with 1
for i in inputList:
    if i in dictionary:
        dictionary[i] += 1
    else:
        dictionary[i] = 1

for key, value in dictionary.items():
    print(f"{key}: {value}")
