n = int(input('Enter the length of the list:'))
inputList = list(map(int, input('Enter a number:').strip().split()))[:n]
print(inputList)
# convert to set
sett = set(inputList)
print(sett)
