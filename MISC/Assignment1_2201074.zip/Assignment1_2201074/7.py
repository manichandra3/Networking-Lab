n = int(input('Enter the length of the list: '))
inputList = list(map(int, input('Enter the numbers separated by spaces: ').strip().split()))[:n]

seen = set()
first_repeating = None
# iter through the list and compare with a set
for num in inputList:
    if num in seen:
        first_repeating = num
        break
    seen.add(num)

if first_repeating is not None:
    print(f"The first repeating element is: {first_repeating}")
else:
    print("There are no repeating elements in the list.")