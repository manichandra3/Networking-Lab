n = int(input('Enter a number: '))
dictionary = {}
# dictionary with a list as value
for i in range(n):
    dictionary[i] = [i**2, i**3]
print(dictionary)
