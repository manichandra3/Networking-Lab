n = int(input('Enter the length of the list: '))
list1 = list(map(int, input('Enter the integer elements of the list: ').strip().split()))[:n]
list2 = list(input('Enter the string elements of the list: ').strip().split())[:n]
# returns an iterator of tuples where same indices are paired together
mapped = zip(list1, list2)
print(tuple(mapped))
